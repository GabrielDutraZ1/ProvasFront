document.addEventListener('DOMContentLoaded', () => {
    const textoInput = document.getElementById('campo-texto');
    const totalCaracteres = document.getElementById('contador-caracteres');
    const totalPalavras = document.getElementById('contador-palavras');
    const nomeDesenvolvedor = document.getElementById('nome-desenvolvedor');

    function inserirNome() {
        nomeDesenvolvedor.textContent = 'Seu Nome Aqui';
    }
    inserirNome();

    textoInput.addEventListener('input', () => {
        const texto = textoInput.value;

        const qtdeCaracteres = texto.length;
        totalCaracteres.textContent = qtdeCaracteres;

        const palavrasSeparadas = texto.trim().split(/\s+/);
        const qtdePalavras = texto.trim() === '' ? 0 : palavrasSeparadas.length;
        totalPalavras.textContent = qtdePalavras;

    });
});
